                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:702470
Sub 30$ 3D laser scanner Open harware/software project by Ferretti is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

*update 
French calibration available on github https://github.com/Sardau/Sardauscan 

*update  
http://www.instructables.com/id/Build-a-30-laser/  
 i've adden a instructable to explain how to build, calibrate and use the sardauscan.*  

*update: V0.0.0.4 out : (much) faster better stronger*  

###Sardauscan is a open source Sub 30$ 3D laser scanner that you can easely print yourself.   

####Even 12$ if you already have a hercule HD twist.  I think we can say it's "the cheaper 3d scaner on earth"  


you just need a arduino nano, 1 to 4 line laser and a micro geared stepper  (28BYJ-48)  
(see instruction for BOM)  

no external power needed. just 2 free usb port on your pc : one for the webcam the other for the rest.   

___UPDATE ___  
I’m proud to announce you the release of the open source Software for the “cheapest 3d scanner on earth” the 30$ DIY Sardauscan.  

The software Is written in C# and allow you to compose your Scan task by drag and drop.  

Recommended Process is composed from these scan  
“Scan” => “IrQ filter” => “merge laser” (if you use more than one laser) => “Build Mesh by interpolation “ => “Save STL”.  

But if you are not satisfied with the build-in processing task, or if you prefer use another heavy but powerful software to work with your point clouds like meslab or other,   

you can just “Scan” => “Save Ply” and import them in your preferred application.  

While the software come with a building support of the Sardauscan hardware, and usb camera. You can easely write your own Hardware proxy via plugins.  

You can event build your own task to insert in your scan process.  

Source Code : https://github.com/Sardau/Sardauscan  

real time scan video : https://www.youtube.com/watch?v=TPb-gEVkBYo  
postprocessing start @ 1:50, if you want to see the speed of post processing (smooth, mesh reconstruct, and stl generation )  

French discussion : http://talk.smartfri.odns.fr/index.php?topic=368.0


# Project

## Intro

Seeing the price tag and limitations of commercial scanners I decided to challenge myself to build my own. It had to be cheaper and easy for anybody to build one using a 3D printer.

Result

The "Sardauscan" is a laser scanner, comparable to other professional laser scanners but for less than 20-30 times the price, and it has twice the number of lasers.

My design principles were:

· Keep it simple

· Keep it low cost

· Make it evolutive

· Provide a complete solution

The scanner is completely open source and open hardware:

· The "Sardauscan" software is written in C# - the full source code is available.

· You can write plugins for your own hardware or for your tasks.

The software allows you to scan, smooth, build meshes and export to various formats.

## How does it work?

The principle of a 3D laser scanner is simple.

· A picture of the object is taken without any lasers firing

· One laser is switched on and another picture is taken

· Computing the difference between the two images, a laser trace (profile of the object) is obtained

· By knowing the positions of the camera and laser you can derive the 3D coordinates of all the points on the profile

· You do the same for all the lasers, turn the table and repeat the process until the table has made a full revolution

And there you go, you have a complete point cloud representing your object.

## What do you need ?

· A bunch of M3 (16 and 20 mm)

· A bunch of M4 (12 and 20 mm)

· 1x Arduino nano (Chinese copy, $4) http://www.befr.ebay.be/itm/NEW-Nano-V3-0-ATmega32...

· 1x Chinese Stepper Motor (28BYJ-48) and controller (ULN2003) (5$) http://www.befr.ebay.be/itm/Uln2003-Stepper-Motor...

· 1-4x Line laser 5v ($2.5$ piece) http://www.befr.ebay.be/itm/251688838898?ssPageNa...

· 1x Hercule HD Twist ($15) http://www.befr.ebay.be/itm/Hercules-HD-Twist-5-0...

· 20x20 profile (can be printed : there are plenty of STLs on the net)

· optional 3x 4mm roller ($0.3 piece) (624 bearings

Total: from $26.5 (1 laser) to $35 (4 lasers)

About the 2020 lengths: this is not really important. The only constraint is to have the camera seeing the whole table.

For example, here are the lengths I used for my build:

· 2 x 140mm

· 1 x 120mm

· 1 x 250mm

What to print

All the STL files can be found on Thingiverse:

http://www.thingiverse.com/thing:702470

· 1 x arm_left.stl

· 1x box.stl

· 1x box_door.stl

· 1x box_arduino_clamp.stl

· 1x arm_right.stl

· 1x CORNER.stl

· 1x MOTOR_MOUNT.stl

· 1 to 4 x laser_holder.stl

· 1X Camera_HOLDER_LOWER_PART.stl

· 1x Camera_HOLDER_UPPER_PART.stl

· 1x center_axe_MINIMAL.stl OR 1x table_AXLE.stl (OPTIONAL)

· 3x roller_baseV2.stl

· you can print 12x M4_tslot_nut.stl if you use a 20x20 profile and you don't have any

Remarks:

· The 2020 profiles are just here for ease of use. You can use whatever you have: wood, metal, …

· If you want to use another camera, you will need to adapt “Camera_HOLDER_UPPER_PART” to match it

· The bearing are optional. They are only necessary if you want to scan heavy objects or don't have a perfectly flat table

· The build is simple, just look at the pictures. You can't do it wrong

· Put the motor at the center, place the 3 profiles around and screw them. Place the corner, screw, put the arms, screw, …

· There is a hole for each screw, you can’t get it wrong.

· For the wiring, please refer to the diagram.

## Firmware

At this point all you need to complete the hardware part is to upload the firmware to the Arduino. You will need the Arduino IDE or another sketch editor.

The firmware (a regular Arduino sketch) is available at: https://github.com/Sardau/Sardauscan

You will also need to install the AccelStepper library in order to compile it: https://github.com/adafruit/AccelStepper

· Edit configuration.h to match your wiring.

· Upload it to your Arduino

Now that the hardware is ready, test it!

· Connect to your Arduino with your IDE

· Type “Sardauscan” – the Arduino should answer “yes”

· Try the stepper: type “T R 100” – your table should turn 100 steps

· Try the laser: type “L 0 1” for the first (0) laser to fire (1) – the first laser should light up

If something doesn’t work, check your wiring and configuration.h – it should match.

## Software and Calibration

To install the Sardauscan software, go to github (see link above) and download the latest binary version. Extract it and launch the executable.

In the main interface, you will see 3 red icons – one for the table, one for the lasers and one for the camera. Click on them to connect to the hardware (right click to disconnect).

If you use the standard Sardauscan firmware the table and the laser switches are linked.

Now that the hardware is ready and the software connects to it, here comes the tricky part: calibration.

The calibration takes 3 steps:

· A manual calibration

· The build dimension

· The "Adjust" correction

Be careful during the calibration: the result quality directly depends on it.

To calibrate:

· Click the target icon and the ‘Physical’ button.

· Move your camera so that the vertical in the preview window crosses the exact center of the table.

· Click on the center of the table in the preview window. The lines will help you align the calibration object.

· Place the calibration object (see STL on Thingiverse) on the table, flat area facing the camera – use the horizontal line for help.

· Click on the first laser icon on top to light up the first laser. Align the laser line to the vertical line in the preview window.

· Repeat for all your lasers.

Build dimension:

· Click on the “build dimension” button and enter your build dimension.

Adjust:

· As a perfect calibration is difficult to achieve, especially with a higher number of lasers, the correction step will help you correct the previous errors.

· Place your calibration object on the center of the table and click “quick scan”.

· When the scan is completed you will see a top view of it. Each color corresponds to a different laser.

· The goal is to superimpose as best as possible the different laser scans: select a laser in the combo box and rotate (left mouse button), scale (middle mouse button) and pan (right mouse button) the scan.

Congratulations , your calibration is done!

## Dafuq is this interface ?

To be evolutive the software is designed around tasks and processes.

When you open the program you will see to the left a list of available tasks – you can drag them to the process list on the right then press the ‘Play’ icon at the bottom.

Here is a non-exhaustive list of the available tasks:

· Scan: scan an object

· Grab Pictures: take pictures of the object for use in a photogrammetry program

· Filter IQR: remove noise from the data with an interquartile range filter

· Filter median: remove noise from the data with a median filter

· Angle: merge laser scan by angle – smooth the scan and filter noise

· Bezier: smooth the data by fitting a Bezier curve

· Surface: smooth the data with a Laplace surface smooth

· Save ply: save a PLY file to use with MeshLab or any other point cloud software

· Save stl: save the STL file

<iframe src="//www.youtube.com/embed/TPb-gEVkBYo" frameborder="0" allowfullscreen></iframe>

## Developer Corner : Evolution ? Own hardware ? Plugins ?

As mentionned the software is not linked to the Sardauscan build – it is made to be evolutive.

You can do almost whatever you want with plugins.

You have a magical algorithm?

Do a plugin for it !

You have a custom image acquisition hardware ?

Do a plugin !

You want to use your own hardware firmware for the table or the laser ?

Do a plugin !

You can look at the github repository, there are some plugins samples. It is really simple to code.

To use the plugin, just copy then in the "plugin" subdirectory.

Happy scanning !